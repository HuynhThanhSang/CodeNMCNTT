#tim kiem tuan tu (sequential serching)
def tktt(x,kq):
    n=len(kq)
    k=-1
    for i in range(0,n,1):
        if sequence[i]==x:
            k=1
            break
        return k
